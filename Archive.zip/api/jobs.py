def some_task():
    print('RUNNING MY FIRST TASK')