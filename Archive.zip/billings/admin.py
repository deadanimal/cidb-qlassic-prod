from billings.models import ClaimApplication
from django.contrib import admin

from .models import ClaimApplication

# Register your models here.
admin.site.register(ClaimApplication)