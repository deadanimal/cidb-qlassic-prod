from django.apps import AppConfig


class BillingsConfig(AppConfig):
    name = 'billings'
